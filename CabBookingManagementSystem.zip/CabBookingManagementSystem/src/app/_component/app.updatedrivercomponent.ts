import {Component, OnInit} from '@angular/core'
import { Driver } from '../_model/app.driver';
import { DriverService } from '../_service/app.driverservice';
import {Router} from '@angular/router'


@Component({
    selector:'updatedriver',
    templateUrl:'../_html/app.updatedriver.html'
   
})


    export class UpdateDriverComponent {
    
    
    driver:Driver

    constructor(private service:DriverService,private router:Router){
      
    }



nameError="";
validateDriverName(){
  var name = new RegExp(/^[A-Z][A-Za-z 0-9]{3,20}$/);
  if(!name.test(this.driver.driverName)){
    this.nameError = "First Letter should be capital with 3-20 characters!"
    return false;
}
else{
    this.nameError = "";
    return true;
}
}
emailError="";
validateEmail():boolean{
  
  var pattern=new RegExp(/^[a-zA-Z0-9.]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/i);
  
  if(this.driver.driverEmail==null){
    this.emailError="Email address cannot be empty!"
    return  false;
  }
  else if(!pattern.test(this.driver.driverEmail)){
    this.emailError="email should be in the form of abc@xyz.com!"
    return  false;

  }
  else{
    this.emailError="";
    return true;
  }

}
contactError="";
validateContact():boolean{
  var pattern = new RegExp(/^[0-9]{10}$/);
  
    if(this.driver.driverContact==null){
      this.contactError="Contact details cannot be empty!"
      return false;
    
  }
  else if(!pattern.test(this.driver.driverContact)){
    this.contactError="Contact number can only be 10 digits long! "
    return false;
  }
  
  else{
    this.contactError="";
    return true;
  }

}
DLError="";
validateDL():boolean{
  
  if(this.driver.drivingLicence==null){
      this.DLError="DL details cannot be empty!"
      return false;
    }
    
    
        
        else{
          this.DLError="";
          return true;
        }
       

  }
   
  searchDriver(driverId:number){
    
           
           
           this.service.searchDriver(driverId).subscribe((data:Driver)=>{this.driver=data}, error=>{alert(error.error)})
            
    
    }

    updateDriver(){
       if(this.validateDriverName() && this.validateEmail() && this.validateContact() && this.validateDL()){
      
        this.service.updateDriver(this.driver).subscribe((success:string)=>{alert(success);this.router.navigate(['/admin']);},error=>{alert(error.error);})
       }
    }
}