import {Component} from '@angular/core';
import { DriverService } from '../_service/app.driverservice';
import {Router} from '@angular/router';




@Component({
    selector:'test',
    templateUrl:'../_html/app.adddriver.html'
})

export class AddDriverComponent  {
  
   model:any={driverId:null,driverName:null,driverEmail:null,driverContact:null,drivingLicence:null};
  


    constructor(private service:DriverService,private router:Router){} 
    nameError="";
    validateDriverName(){
      var name = new RegExp(/^[A-Z][A-Za-z 0-9]{3,20}$/);
      if(!name.test(this.model.driverName)){
        this.nameError = "First Letter should be capital with 3-20 characters!"
        return false;
    }
    else{
        this.nameError = "";
        return true;
    }
    }
    emailError="";
    validateEmail():boolean{
      
      var pattern=new RegExp(/^[a-zA-Z0-9.]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/i);
      
      if(this.model.driverEmail==null){
        this.emailError="Email address cannot be empty!"
        return  false;
      }
      else if(!pattern.test(this.model.driverEmail)){
        this.emailError="email should be in the form of abc@xyz.com!"
        return  false;

      }
      else{
        this.emailError="";
        return true;
      }

    }
    contactError="";
    validateContact():boolean{
      var pattern = new RegExp(/^[0-9]{10}$/);
      
        if(this.model.driverContact==null){
          this.contactError="Contact details cannot be empty!"
          return false;
        
      }
      else if(!pattern.test(this.model.driverContact)){
        this.contactError="Contact number can only be 10 digits long! "
        return false;
      }
      
      else{
        this.contactError="";
        return true;
      }

    }
    DLError="";
    validateDL():boolean{
      
      if(this.model.drivingLicence==null){
          this.DLError="DL details cannot be empty!"
          return false;
        }
        
        
            
            else{
              this.DLError="";
              return true;
            }
           

      }

    
   

      addDriver():any{
      if(this.validateDriverName && this.validateEmail && this.validateContact && this.validateDL){
        if( this.model.driverName!=null && this.model.driverEmail!=null && this.model.driverContact!=null && this.model.drivingLicence!=null)

          this.service.addDriver(this.model).subscribe((success)=>{alert(success);this.router.navigate(['/admin']);},error=>{alert(error.error);})

      }
    }
    }

    




   
  
