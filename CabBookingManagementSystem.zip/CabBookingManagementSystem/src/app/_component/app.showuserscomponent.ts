import {Component, OnInit} from '@angular/core';
import {UserService} from '../_service/app.userservice'
import {User} from '../_model/app.user';
import { Router } from '@angular/router';



@Component({
    selector:'showuser',
    templateUrl:'../_html/app.showusers.html'
})

export class ShowAllUserComponent implements OnInit{
    update:any;
    users:any[]=[];
    
    
    settings = {
        columns: {
          driverId: {
            title: 'driverId'
          },
          driverName: {
            title: 'driverName'
          },
          driverEmail: {
              title: 'driverEmail'
          },
          driverContact: {
              title: 'driverContact'
          },
          drivingLicence: {
              title: 'drivingLicence'
          }
        },
        actions: {
            delete: false,
            add: false,
            edit: false,
            position: 'right'
        },
        pager:{
            display:true,
            perPage: 5
        }
      };

    constructor(private service:UserService, private router:Router){
    }

    ngOnInit(){ 
       
            this.service.getAllUsers().subscribe((data:User[])=>this.users=data);
        
    }
   
    
}