import { Component, OnInit} from '@angular/core'
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../_service/app.bookingservice'

import { DatePipe } from '@angular/common';

@Component({
    providers: [DatePipe],
    selector: 'addbooking',
    templateUrl:'../_html/app.addbooking.html'
})
export class AddBookingComponent {
    model:any={bookingId:null,status:null,modeOfPayment:null, startTime:null,endTime:null,source:null,destination:null};
    source:string[];
    destination:string[];
    
    
    dateFormat='dd-MM-yyyy';

    minDate:any;
    maxDate:any;

    errorFlag:boolean=false;
    
    constructor(private service:BookingService,private router:Router,private bookingService:BookingService,private route:ActivatedRoute,private datepipe:DatePipe){
        
    }

    
   sourceError="";
   validateSource(){
       if(this.model.source==null){
           this.sourceError="Source cannot be empty"
           return false;
       }
       else{
           this.sourceError="";
           return true;
       }
   }

   destinationError="";
   validateDestination(){
       if(this.model.destination==null){
            this.destinationError="Destination cannot be empty"
            return false;
       }
       else if(this.model.source == this.model.destination){
           this.destinationError="Source and destination cannot be same"
           return false;
       }
       else{
           this.destinationError=""
           return true;
       }
   }
    
    // durationError="";
    // validateTestDuration():boolean{
    //   var pattern = new RegExp(/^([0-9][0-9]):([0-5][0-9]):([0-5][0-9])$/i);
    //   if(!pattern.test(this.model.testDuration)){
    //     this.durationError="Enter duration in 'HH:mm:ss' format only!"
    //     return  false;
    //   }
    //   else{
    //     this.durationError="";
    //     return true;
    //   }

    // }
    startTimeError="";
    validateStartTime():boolean{
        
      var startdate=Date.parse(this.model.startTime);
      var currentdate=new Date().getTime();
        if(this.model.startTime==null){
          this.startTimeError="Start Time cannot be empty."
          return false;
        
      }
      else if(currentdate>startdate){
        this.startTimeError="Start time cannot be in the past!"
        return false;
      }
      
      else{
        this.startTimeError="";
        return true;
      }
    }
    endTimeError="";
    validateEndTime():boolean{
      var startdate=Date.parse(this.model.startTime);
      var startDateMs=startdate + 7*24*60*60*1000
      var enddate=Date.parse(this.model.endTime);
      var currentdate=new Date().getTime();
      if(this.model.endTime==null){
          this.endTimeError="End Time cannot be empty!"
          return false;
        }
      else if(startdate>enddate){
          this.endTimeError="End time cannot be before Start Time!"
          return false;
      }
      else if(currentdate>enddate){
        this.endTimeError="End time cannot be in the past!"
        return false;
      }
      else if(enddate>startDateMs){
        this.endTimeError="Cab cannot be booked for more than 7 days in advance"
        return false;
      }
      else{
        this.endTimeError="";
        return true;
      }
    }  

    
   

    addBooking(source,destination,cabid,userid,data:any):any{
      if(this.validateSource() && this.validateStartTime && this.validateEndTime && this.validateDestination()){
        if( this.model.modeOfPayment!=null && this.model.source!=null && this.model.destination!=null && this.model.startTime!=null && this.model.endTime!=null)

          this.service.addBooking(source,destination,cabid,userid,this.model).subscribe((success)=>{alert(success);this.router.navigate(['/admin']);},error=>{alert(error.error);})

      }
    }
    }

    

   
       

