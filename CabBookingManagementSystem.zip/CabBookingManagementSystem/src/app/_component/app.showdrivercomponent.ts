import {Component, OnInit} from '@angular/core';
import {DriverService} from '../_service/app.driverservice'
import {Driver} from '../_model/app.driver';
import { Router } from '@angular/router';



@Component({
    selector:'showdriver',
    templateUrl:'../_html/app.showalldrivers.html'
})

export class ShowAllDriverComponent implements OnInit{
    update:any;
    drivers:any[]=[];
    
    
    settings = {
        columns: {
          driverId: {
            title: 'driverId'
          },
          driverName: {
            title: 'driverName'
          },
          driverEmail: {
              title: 'driverEmail'
          },
          driverContact: {
              title: 'driverContact'
          },
          drivingLicence: {
              title: 'drivingLicence'
          }
        },
        actions: {
            delete: false,
            add: false,
            edit: false,
            position: 'right'
        },
        pager:{
            display:true,
            perPage: 5
        }
      };

    constructor(private service:DriverService, private router:Router){
    }

    ngOnInit(){ 
        
            this.service.getAllDrivers().subscribe((data:Driver[])=>this.drivers=data);
        
    }
   
    
}