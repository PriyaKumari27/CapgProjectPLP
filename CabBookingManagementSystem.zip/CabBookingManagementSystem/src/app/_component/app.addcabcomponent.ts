import {Component} from '@angular/core'
import {Router} from '@angular/router'

import {CabService} from '../_service/app.cabservice'

@Component({
    selector:'cab',
    templateUrl:'../_html/app.addcab.html'
})

export class AddCabComponent{
    

    driverId:number
    model:any={cabId:null,cabNumber:null,cabName:null,cabModel:null,cabType:null}
    constructor(private service:CabService,private router:Router){} 
    idError="";
    validateDriverId(){
        if(this.driverId==null){
            this.idError="Driver id cannot be empty"
            return false;
        }
        else{
            this.idError=""
            return true;
        }
    }
    numberError
    validateCabNumber(){
      var name = new RegExp(/^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$/);
      if(this.model.cabNumber==null){
          this.numberError="Cab Number cannot be empty"
          return false;

      }
      else if(!name.test(this.model.cabNumber)){
        this.numberError = "Cab Number should be like MP 09 AB 1234"
        return false;
    }
    else{
        this.numberError = "";
        return true;
    }
    }
    nameError="";
    validateCabName():boolean{
        var name = new RegExp(/^[A-Z][A-Za-z 0-9]{3,20}$/);
      if(!name.test(this.model.cabName)){
        this.nameError = "First Letter should be capital with 3-20 characters!"
        return false;
      }
      
      
      
      else if(this.model.cabName==null){
        this.nameError="Cab Name cannot be empty!"
        return  false;
      }
      
      else{
        this.nameError="";
        return true;
      }

    }
    modelError="";
    validateCabModel():boolean{
     
      
        if(this.model.cabModel==null){
          this.modelError="Cab Model cannot be empty!"
          return false;
        
      }
      
      
      else{
        this.modelError="";
        return true;
      }

    }
    typeError="";
    validateCabType():boolean{
      
      if(this.model.cabType==null){
          this.typeError="Cab Type cannot be empty!"
          return false;
        }
        
        
            
            else{
              this.typeError="";
              return true;
            }
           

      }

    
   

      addCab(driverId:number){
      if(this.validateCabNumber&& this.validateCabName && this.validateCabType && this.validateCabModel){
        if( this.model.cabNumber!=null && this.model.cabName!=null && this.model.cabType!=null && this.model.cabType!=null)

           this.service.addCab(driverId,this.model).subscribe((success:string)=>{alert(success);this.router.navigate(['/admin']);},error=>{alert(error.error);})
        }
    }
    }

    

