import {Component, OnInit} from '@angular/core'
import { BookingService } from '../_service/app.bookingservice'
import { Booking } from '../_model/app.booking';
import { Router } from '@angular/router';

@Component({
    selector:'cancelbooking',
    templateUrl:'../_html/app.cancelbooking.html'
})

export class CancelBookingComponent {
   bookingList:Booking[]=[];
   

    router: any;
    constructor(private service:BookingService){
    }
    ngOnInit(){
        if(sessionStorage.getItem("role")!= "admin"){
            this.router.navigate(['/error403'])
        }
    }
   
    cancelBooking(bookingId:number):any{

        
        this.service.cancelBooking(bookingId).subscribe((success:string)=>{alert(success);this.router.navigate(['/admin']);},error=>{alert(error.error);});
        
    }
}
    