import {Component, OnInit} from '@angular/core';
import {CabService} from '../_service/app.cabservice'
import {Cab} from '../_model/app.cab';
import { Router } from '@angular/router';



@Component({
    selector:'showcab',
    templateUrl:'../_html/app.showcabs.html'
})

export class ShowAllCabComponent implements OnInit{
    update:any;
    cabs:any[]=[];
    
    
    settings = {
        columns: {
          cabId: {
            title: 'cabId'
          },
          cabNumber: {
            title: 'cabNumber'
          },
          cabName: {
              title: 'cabName'
          },
          cabModel: {
              title: 'cabModel'
          },
          cabType: {
              title: 'cabType'
          }
        },
        actions: {
            delete: false,
            add: false,
            edit: false,
            position: 'right'
        },
        pager:{
            display:true,
            perPage: 5
        }
      };

    constructor(private service:CabService, private router:Router){
    }

    ngOnInit(){ 
        
            this.service.getAllCabs().subscribe((data:Cab[])=>this.cabs=data);
        
    }
   
    
}