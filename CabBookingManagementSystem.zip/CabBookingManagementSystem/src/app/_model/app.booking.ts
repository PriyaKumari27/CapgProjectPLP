import { User} from '../_model/app.user'
import { Cab } from '../_model/app.cab'


export class Booking{
    bookingId: number;
    status: string;
    startTime:string;
    endTime:string;
    modeOfPayment: string;
    source:string;
    destination:string;
    cab: Cab;
    user: User;
    
    price: number;
   
}