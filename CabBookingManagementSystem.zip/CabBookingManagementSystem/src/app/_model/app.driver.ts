export class Driver{
    driverId:number;
    driverName:string;
    driverEmail:string;
    driverContact:string;
    drivingLicence:string;
}