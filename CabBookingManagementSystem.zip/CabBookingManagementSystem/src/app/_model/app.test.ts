import { Time} from "@angular/common";



export class Test{
    testId:number;
    testName:string;
    testDuration:any;
    startTime:any;
    endTime:any;
}