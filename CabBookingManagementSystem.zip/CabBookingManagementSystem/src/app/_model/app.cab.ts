export class Cab{
    cabId:number;
    cabNumber:string;
    cabName:string;
    cabModel:string;
    cabType:string;
}