export class User{
    userId:any;
    userName:string;
    userPassword:string;
    userEmail:string;
    userContact:string
    isAdmin:boolean;
    isDeleted:boolean;

}