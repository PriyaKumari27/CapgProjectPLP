﻿import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {Routes, RouterModule} from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'
import {ConfirmationPopoverModule} from 'angular-confirmation-popover'


import {HomeComponent} from './_component/app.homecomponent'
import {AdminHomeComponent} from './_component/app.adminhomecomponent'
import {AddBookingComponent} from './_component/app.addbookingcomponent'



import {AddDriverComponent} from './_component/app.adddrivercomponent'
import {ShowAllDriverComponent} from './_component/app.showdrivercomponent'
import {UpdateDriverComponent} from './_component/app.updatedrivercomponent';
import {AddCabComponent} from './_component/app.addcabcomponent'
import {ShowAllCabComponent} from './_component/app.showcabcomponent'
import {ShowAllUserComponent} from './_component/app.showuserscomponent';
import {UserHomeComponent} from './_component/app.userhomecomponent';

import {CancelBookingComponent} from './_component/app.cancelbookingcomponent'
 



const myroute:Routes = [
    {path: 'home', component: HomeComponent},
    {path: 'admin', component: AdminHomeComponent},
    {path: 'user', component: UserHomeComponent},
    {path:'createbooking',component:AddBookingComponent},
    {path:'adddriver', component:AddDriverComponent},
    {path:'showdrivers',component:ShowAllDriverComponent},
    {path:'updatedriver',component:UpdateDriverComponent},
    {path:'addcab',component:AddCabComponent},
    {path:'showcabs',component:ShowAllCabComponent},
    {path:'showusers',component:ShowAllUserComponent},

    {path:'cancelbooking',component:CancelBookingComponent}
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        RouterModule.forRoot(myroute),
        NgxPaginationModule,
        ConfirmationPopoverModule.forRoot({
        confirmButtonType:'danger'})
    ],
    declarations: [
        AddBookingComponent,CancelBookingComponent,
        HomeComponent,AdminHomeComponent,UserHomeComponent,
        AppComponent, AddDriverComponent,ShowAllDriverComponent,
        UpdateDriverComponent,
        AddCabComponent,ShowAllCabComponent,
        ShowAllUserComponent
        
		], 
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }