import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
    providedIn:'root'
})

export class CabService{
    constructor(private myhttp:HttpClient){}

    addCab(driverId:number,data:any){
       
        return this.myhttp.post("http://localhost:9099/addcab?driverid="+driverId,data);
        
    }
    getAllCabs(){
        
        return this.myhttp.get("http://localhost:9099/showcabs");

    }

    deleteTest(testId:number){
        return this.myhttp.delete("http://localhost:9088/removetestsubmit?testid="+testId);
    }

    searchDriver(driverId:number){
       
        return this.myhttp.get("http://localhost:9099/showdriverinput?driverid="+driverId);

    }

}