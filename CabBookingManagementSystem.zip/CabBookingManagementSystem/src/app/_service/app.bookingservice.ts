import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
    providedIn:'root'
})

export class BookingService{
    constructor(private myhttp:HttpClient){}
    source:string;
    destination:string;

    cancelBooking(bookingId:number){
       return this.myhttp.post("http://localhost:9099/cancelbooking?bookingid="+bookingId,null);

      
    }

    addBooking(source,destination,cabid,userid,data:any){
        return this.myhttp.post("http://localhost:9099/createbooking?source="+source+"&destination="+destination+"&cabid="+cabid+"&userid="+userid,data);
    }
    
}
